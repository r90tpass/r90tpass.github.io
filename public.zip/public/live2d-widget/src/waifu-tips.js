import initWidget from "./index.js";

window.initWidget = initWidget;
